const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const cliente = new Schema({
    cpf: Number,
    nome: String,
    }    );
    dataCadastro: {
        type: Date,
        default: Date.now,
    } 
cliente.index({cpf: 1}, {unique: true});

module.exports = mongoose.model('Cliente', cliente);