

function newFunction() {
    const mongoose = require('mongoose');
    const Schema = mongoose.Schema;

    const pessoa = new Schema({
        cpf: Number,
        nome: String,
    });
    dataCadastro: {
        type: Date,
            ;
        Date.now,
            ;
    }
    pessoa.index({ cpf: 1 }, { unique: true });

    module.exports = mongoose.model('Pessoa', pessoa);
}
