const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const clientePessoa = new Schema({
    cpf: {
        type:mongoose.types.ObjectId,
        ref:'Cliente',     
        required:true,
    },
    pessoaId: {
        type:mongoose.types.ObjectId,
        ref:'Pessoa',
        required:true,
    },
    nome:   {
        type: String,
        required: true,
    },
     
    dataCadastro: {
        type: Date,
        default: Date.now,
    } 
    clientePessoa.index({cpf: 1}, {unique: true});

module.exports = mongoose.model('ClientePessoa', clientePessoa);