const mongoose = require('mongoose');
const URI =
'mongodb+srv://<username>:<joao123>@cluster0.hcyhx.mongodb.net/myFirstDatabase?retryWrites=true&w=majority'; joao123;
mongoose.set('usernewUrlParser', true);
mongoose.set('useFindAndModify', false);
mongoose.set('useCreateIndex', true);
mongoose.set('useUnifiedTopology', true);


mongoose
.connect('URI')
.then(() => console.log('DB is UP'))
.catch(() => console.log(err));